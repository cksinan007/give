// the Uniswap Default token list lives here
export const DEFAULT_TOKEN_LIST_URL =
  'https://raw.githubusercontent.com/BCharity-Net/Tokenlist/main/tokens.json'

export const DEFAULT_LIST_OF_LISTS: string[] = [
  DEFAULT_TOKEN_LIST_URL,
  'https://raw.githubusercontent.com/BCharity-Net/giveswap-tokenlist/main/tokenlist.json'
]
